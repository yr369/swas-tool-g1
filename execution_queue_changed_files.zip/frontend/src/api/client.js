/**
 * api.js - a thin wrapper around the backend's REST API.
 *
 * Every function here corresponds to one endpoint we already built and
 * tested with curl in the backend. Keeping all fetch() calls in one file
 * means components never construct URLs themselves - if an endpoint path
 * ever changes, there's exactly one place to update it.
 */

const BASE = "/api";

async function request(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json", ...options.headers },
    ...options,
  });

  if (!res.ok) {
    let detail = `Request failed (${res.status})`;
    try {
      const body = await res.json();
      detail = body.detail || detail;
    } catch {
      // response wasn't JSON - keep the generic message
    }
    throw new Error(detail);
  }

  // Some endpoints (like /scan) return a small confirmation object;
  // all of them return JSON, so this is safe across the board.
  return res.json();
}

export const api = {
  // Ops / observability
  healthDashboard: () => request("/health/dashboard"),

  // Projects
  listProjects: () => request("/projects"),
  listChronology: () => request("/projects/chronology"),
  getProject: (id) => request(`/projects/${id}`),
  getAuthPolicy: (id) => request(`/projects/${id}/auth-policy`),
  listAuthSessions: (id) => request(`/projects/${id}/auth-sessions`),
  updateProject: (id, payload) => request(`/projects/${id}`, { method: "PATCH", body: JSON.stringify(payload) }),
  createProject: (name, platform) =>
    request("/projects", { method: "POST", body: JSON.stringify({ name, platform }) }),
  bulkProjectAction: (projectIds, action) =>
    request("/projects/bulk-action", { method: "POST", body: JSON.stringify({ project_ids: projectIds, action }) }),
  deleteProject: (id, confirmName) =>
    request(`/projects/${id}`, { method: "DELETE", body: JSON.stringify({ confirm_name: confirmName }) }),
  listScanNotes: (projectId) => request(`/projects/${projectId}/notes`),
  dismissScanNote: (noteId) => request(`/notes/${noteId}/dismiss`, { method: "PATCH" }),

  // Scope
  listScope: (projectId) => request(`/projects/${projectId}/scope`),
  listScopeOverlaps: (projectId) => request(`/projects/${projectId}/scope/overlaps`),
  listDurationEstimates: (projectId) => request(`/projects/${projectId}/scope/duration-estimates`),
  getOutcomeTrend: (projectId, weeks) => request(`/projects/${projectId}/outcome-trend${weeks ? `?weeks=${weeks}` : ""}`),
  screenshotUrl: (targetId) => `${BASE}/targets/${targetId}/screenshot`,
  addScopeTarget: (projectId, target) =>
    request(`/projects/${projectId}/scope`, { method: "POST", body: JSON.stringify(target) }),
  updateScopeTarget: (projectId, targetId, updates) =>
    request(`/projects/${projectId}/scope/${targetId}`, { method: "PATCH", body: JSON.stringify(updates) }),
  deleteScopeTarget: (projectId, targetId) =>
    request(`/projects/${projectId}/scope/${targetId}`, { method: "DELETE" }),
  bulkAddScopeTargets: (projectId, payload) =>
    request(`/projects/${projectId}/scope/bulk`, { method: "POST", body: JSON.stringify(payload) }),
  rescanTarget: (projectId, targetId) =>
    request(`/projects/${projectId}/scope/${targetId}/rescan`, { method: "POST" }),

  // Scope intake (AI-assisted)
  parseScopeText: (platform, rawText) =>
    request("/scope/parse-text", {
      method: "POST",
      body: JSON.stringify({ platform, raw_text: rawText }),
    }),
  parseScopeFile: async (platform, file) => {
    const form = new FormData();
    form.append("file", file);
    const res = await fetch(`${BASE}/scope/parse-file?platform=${encodeURIComponent(platform)}`, {
      method: "POST",
      body: form,
    });
    if (!res.ok) {
      let detail = `Request failed (${res.status})`;
      try {
        const body = await res.json();
        detail = body.detail || detail;
      } catch {
        // response wasn't JSON
      }
      throw new Error(detail);
    }
    return res.json();
  },
  confirmScope: (payload) =>
    request("/scope/confirm", { method: "POST", body: JSON.stringify(payload) }),

  // Pipeline
  startScan: (projectId) => request(`/projects/${projectId}/scan`, { method: "POST" }),
  setSchedule: (projectId, intervalHours, runAt = null) =>
    request(`/projects/${projectId}/schedule`, {
      method: "PUT",
      body: JSON.stringify({ interval_hours: intervalHours, run_at: runAt }),
    }),
  listPhaseRuns: (projectId) => request(`/projects/${projectId}/phase-runs`),
  listScanRuns: (projectId) => request(`/projects/${projectId}/scan-runs`),

  // Execution queue
  listQueue: () => request("/queue"),
  enqueueProject: (projectId, priority = false) =>
    request("/queue", { method: "POST", body: JSON.stringify({ project_id: projectId, priority }) }),
  reorderQueueItem: (queueId, newPosition) =>
    request(`/queue/${queueId}/reorder`, { method: "PATCH", body: JSON.stringify({ new_position: newPosition }) }),
  cancelQueueItem: (queueId) => request(`/queue/${queueId}`, { method: "DELETE" }),

  // Live scan progress - returns a plain WebSocket URL (not JSON), for
  // components to open themselves via `new WebSocket(...)`. Derives ws://
  // vs wss:// from the page's own protocol so it works the same behind
  // plain HTTP (current OCI setup) or HTTPS (once a domain is added).
  progressSocketUrl: (projectId) => {
    const proto = window.location.protocol === "https:" ? "wss:" : "ws:";
    return `${proto}//${window.location.host}/ws/projects/${projectId}`;
  },

  // Findings
  listFindings: (projectId) => request(`/projects/${projectId}/findings`),
  listAllFindings: (filters = {}) => {
    const params = new URLSearchParams();
    if (filters.severity) params.set("severity", filters.severity);
    if (filters.tool_name) params.set("tool_name", filters.tool_name);
    if (filters.q) params.set("q", filters.q);
    if (filters.likely_program_outcome) params.set("likely_program_outcome", filters.likely_program_outcome);
    if (filters.status) params.set("status", filters.status);
    if (filters.sort) params.set("sort", filters.sort);
    if (filters.limit) params.set("limit", filters.limit);
    const qs = params.toString();
    return request(`/findings${qs ? `?${qs}` : ""}`);
  },
  buildExportQuery: ({ severities, tools, vulnTypes } = {}) => {
    const params = new URLSearchParams();
    if (severities?.length) params.set("severities", severities.join(","));
    if (tools?.length) params.set("tools", tools.join(","));
    if (vulnTypes?.length) params.set("vuln_types", vulnTypes.join(","));
    const qs = params.toString();
    return qs ? `?${qs}` : "";
  },
  exportFindingsUrl: (projectId, filters) =>
    `${BASE}/projects/${projectId}/findings/export${api.buildExportQuery(filters)}`,
  reportUrl: (projectId, filters) =>
    `${BASE}/projects/${projectId}/report.md${api.buildExportQuery(filters)}`,
  bulkUpdateFindingStatus: (findingIds, status) =>
    request("/findings/bulk-status", { method: "PATCH", body: JSON.stringify({ finding_ids: findingIds, status }) }),

  // Run-to-run diff
  getDiff: (projectId) => request(`/projects/${projectId}/diff`),

  // Triage
  triageFinding: (findingId) => request(`/findings/${findingId}/triage`, { method: "POST" }),
  getReportDraft: (findingId) => request(`/findings/${findingId}/report-draft`),
  triageAll: (projectId) => request(`/projects/${projectId}/triage-all`, { method: "POST" }),

  // Readiness
  getReadiness: (findingId) => request(`/findings/${findingId}/readiness`),

  // Outcomes
  logOutcome: (payload) => request("/outcomes", { method: "POST", body: JSON.stringify(payload) }),
  getSignatureStats: (signature) =>
    request(`/outcomes/signature-stats${signature ? `?signature=${encodeURIComponent(signature)}` : ""}`),

  // Health
  health: () => request("/health"),
};
